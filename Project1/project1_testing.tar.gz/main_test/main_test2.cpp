#include "History.h"
int main()
{
  History h(2, 2);
  h.record(1, 1);
  h.display();
}
