#include "City.h"
int main()
{
  City c(10, 18);
  c.addPlayer(2, 2);
}
