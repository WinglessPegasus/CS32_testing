#include "Player.h"
#include "City.h"
int main()
{
  City a(10, 20);
  Player p(&a, 2, 3);
  Flatulan f(&a, 1, 1);
}
