#include "Player.h"
#include "City.h"
int main()
{
  City c(10, 20);
  Player p(&c, 2, 3);
}
