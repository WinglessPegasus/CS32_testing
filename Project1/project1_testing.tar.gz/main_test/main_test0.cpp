#include "Flatulan.h"
int main()
{}
