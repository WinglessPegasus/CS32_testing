#include "Flatulan.h"
int main()
{
  Flatulan f(nullptr, 1, 1);
}
