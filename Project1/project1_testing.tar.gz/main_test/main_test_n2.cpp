#include "globals.h"
#include "Flatulan.h"
#include "Player.h"
int main()
{
  City a(10, 10);
}
