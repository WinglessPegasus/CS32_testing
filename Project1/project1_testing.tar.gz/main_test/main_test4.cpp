#include "Player.h"
int main()
{
  Player p(nullptr, 1, 1);
}
